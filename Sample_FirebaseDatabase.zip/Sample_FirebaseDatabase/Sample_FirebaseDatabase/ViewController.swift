//
//  ViewController.swift
//  Sample_FirebaseDatabase
//
//  Created by Semi Park on 2022/02/11.
//
// 참고 사이트 : https://fomaios.tistory.com/entry/Firebase-파이어베이스-실시간-데이터베이스-사용해보기Realtime-Database-WriteReadUpdateDelete

import UIKit
import FirebaseDatabase

class ViewController: UIViewController {

    var ref : DatabaseReference!    // 레퍼런스 선언
    
    override func viewDidLoad() {
        super.viewDidLoad()
        ref = Database.database().reference()   // 레퍼런스 만들기
        // 데이터 쓰기
        ref.child("people").child("person").setValue(["name" : "fomagran"])
        
        // 데이터 읽기
//        ref.getData(completion: {(err, snapshot) in
//            print(snapshot.value!)
//        })
        
        // people안에 person안에 name을 알고싶다면
        ref.child("people").child("person").child("name").getData(completion: {(error, snapshot) in
            print(snapshot.value!)
        })
    
    }
}

